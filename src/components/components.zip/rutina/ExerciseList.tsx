'use client'

import { useAppStore } from '@/store/appStore'
import { getExerciseBySlug } from '@/data/gluteos-exercises'
import ExerciseCard from './ExerciseCard'
import CompleteDayButton from './CompleteDayButton'

export default function ExerciseList({ dayNumber, exerciseSlugs, weekNumber }: { dayNumber: number, exerciseSlugs: string[], weekNumber: number }) {
  const { progress } = useAppStore()

  // Verificamos si cada slug listado en el dia tiene un registro instanciado en zustand (fue completado)
  const allCompleted = exerciseSlugs.length > 0 && exerciseSlugs.every(slug => progress.exerciseRecords[slug] !== undefined)

  return (
    <div className="flex flex-col gap-4 mt-8 pb-32">
      {exerciseSlugs.map((slug) => {
        const exercise = getExerciseBySlug(slug)
        // Guard clause para evitar slugs falsos o faltantes en BD
        if (!exercise) return null
        
        // Comprobamos estado asincronico
        const isCompleted = progress.exerciseRecords[slug] !== undefined

        return (
          <div key={slug} className="w-full">
            <ExerciseCard
              exercise={exercise}
              isCompleted={isCompleted}
              slugInfo={{ week: weekNumber, day: dayNumber, slug }}
            />
          </div>
        )
      })}
      
      {/* Boton condicional que requiere la resolucion de allCompleted a true para renderizar */}
      <CompleteDayButton dayNumber={dayNumber} allCompleted={allCompleted} weekNumber={weekNumber} />
    </div>
  )
}
