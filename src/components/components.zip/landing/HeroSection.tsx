import Image from 'next/image'

export default function HeroSection({ lang }: { lang: 'es' | 'en' }) {
  return (
    <section className="relative w-full h-screen flex flex-col items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 w-full h-full">
        <Image
          src="/images/fotos/hero-landing-principal.jpg"
          alt="Hero background"
          fill
          priority
          className="object-cover object-[center_top]"
        />
        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-carbon" />
      </div>

      {/* Logo */}
      <div className="absolute top-6 left-6 z-10">
        <div className="relative w-32 h-10">
          <Image 
            src="/images/logo.svg" 
            alt="VTeamFit" 
            fill 
            className="object-contain object-left" 
            priority
          />
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center text-center px-6 mt-[-10vh]">
        <h1 className="text-5xl md:text-7xl font-black text-white italic uppercase mb-4 tracking-tight drop-shadow-xl text-balance">
          {lang === 'es' ? 'TU MEJOR VERSIÓN' : 'YOUR BEST VERSION'}
        </h1>
        <p className="text-zinc-300 text-lg md:text-xl font-medium mb-12 max-w-sm text-balance">
          {lang === 'es' ? 'Planes de entrenamiento para ti' : 'Training plans for you'}
        </p>

        <button
          onClick={() => document.getElementById('planes')?.scrollIntoView({ behavior: 'smooth' })}
          className="bg-copper text-white uppercase font-bold text-sm md:text-base tracking-widest px-10 py-5 mx-auto rounded-full shadow-[0_0_24px_rgba(255,107,74,0.4)] hover:shadow-[0_0_32px_rgba(255,107,74,0.6)] hover:bg-[#ff8566] transition-all hover:-translate-y-1 active:scale-95 cursor-pointer"
        >
          {lang === 'es' ? 'VER PLANES' : 'SEE PLANS'}
        </button>
      </div>
    </section>
  )
}
