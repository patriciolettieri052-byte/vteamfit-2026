'use client'

import { useEffect, useState } from 'react'

export default function ProgressRing({ completed, total, lang }: { completed: number, total: number, lang: 'es' | 'en' }) {
  const [offset, setOffset] = useState(251.2) // Initial offset (circumference)
  const percentage = Math.min(Math.round((completed / total) * 100), 100)
  
  const radius = 40
  const circumference = 2 * Math.PI * radius

  useEffect(() => {
    const progressOffset = circumference - (percentage / 100) * circumference
    const timer = setTimeout(() => {
        setOffset(progressOffset)
    }, 100)
    return () => clearTimeout(timer)
  }, [percentage, circumference])

  return (
    <div className="relative flex items-center justify-center w-full aspect-square max-w-[240px] mx-auto bg-surface rounded-[3rem] p-8 border border-white/5 shadow-2xl">
      <svg className="w-full h-full transform -rotate-90">
        {/* Background Circle */}
        <circle
          cx="50%"
          cy="50%"
          r={radius}
          stroke="currentColor"
          strokeWidth="8"
          fill="transparent"
          className="text-carbon"
        />
        {/* Progress Circle */}
        <circle
          cx="50%"
          cy="50%"
          r={radius}
          stroke="currentColor"
          strokeWidth="8"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          fill="transparent"
          className="text-copper transition-all duration-1000 ease-out"
        />
      </svg>
      
      {/* Percentage Center */}
      <div className="absolute flex flex-col items-center">
        <span className="text-5xl font-black text-white italic">{percentage}%</span>
        <span className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mt-1">
          {lang === 'es' ? 'Completado' : 'Completed'}
        </span>
      </div>
    </div>
  )
}
